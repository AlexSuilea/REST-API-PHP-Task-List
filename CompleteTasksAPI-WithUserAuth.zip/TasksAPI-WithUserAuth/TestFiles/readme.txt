responsetest.php - Place this into the model folder for testing purposes only

dbtest.php - Place this into the controller folder for testing purposes only

tasktest.php - Place this into the model folder for testing purposes only