//
//  TaskTableViewController.swift
//  ToDoDemo
//
//  Created by Michael Spinks on 04/12/2018.
//  Copyright © 2018 Michael Spinks. All rights reserved.
//

import UIKit

class TaskTableViewController: UITableViewController {
    
    @IBOutlet weak var refreshButton: UIBarButtonItem!
    private var config = URLSessionConfiguration.default
    private var session: URLSession?
    private var apiURL: String = ""
    private var tasksArray: [Task] = [Task]()
    private var numberIncomplete: Int = 0
    public var accessToken: String = ""
    public var refreshToken: String = ""
    public var sessionid: Int = 0
    private var cachable: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Tasks - \(self.numberIncomplete)"
        self.apiURL = Bundle.main.object(forInfoDictionaryKey: "APIUrl") as! String
        self.config.timeoutIntervalForRequest = 30
        self.session = URLSession(configuration: self.config)
        
        
        
        if let savedAccessToken = UserDefaults.standard.string(forKey: "accessToken"), let savedRefreshToken = UserDefaults.standard.string(forKey: "refreshToken") , let savedSessionID = UserDefaults.standard.string(forKey: "sessionID") {
            self.accessToken = savedAccessToken
            self.refreshToken = savedRefreshToken
            self.sessionid = Int(savedSessionID)!
        }
        else {
            self.dismiss(animated: true, completion: nil)
        }

        
        callGetTasksAPI()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: UIApplication.didBecomeActiveNotification, object: nil)
    }

    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tasksArray.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath)
        
        cell.textLabel?.text = self.tasksArray[indexPath.row].getTitle()
        if self.tasksArray[indexPath.row].getCompleted() == "Y" {
            cell.backgroundColor = .green
        }
        else {
            cell.backgroundColor = .white
        }
        if let dline = self.tasksArray[indexPath.row].getDeadline() {
            cell.detailTextLabel?.text = "Deadline: \(dline)"
        }
        else {
            cell.detailTextLabel?.text = "Deadline: None"
        }
        
        return cell
    }
    
    
    // MARK: - Navigation


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        
        if segue.identifier == "showDetail" {
            
            let indexPath: NSIndexPath = self.tableView.indexPathForSelectedRow! as NSIndexPath
            
            let selectedTask: Task = tasksArray[indexPath.row];
            
            let destVC = segue.destination as? TaskViewController
            destVC?.passedInTask = selectedTask
            
        }
        
    }
    

    
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
    
        let deleteAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Delete" , handler: { (action:UITableViewRowAction, indexPath: IndexPath) -> Void in
            
            var attempts: Int = 0
            let taskToDelete = self.tasksArray[indexPath.row]
           
            var deleteTaskURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/tasks/\(String(describing: taskToDelete.getID()!))")!)
            
            deleteTaskURL.httpMethod = "DELETE"
            deleteTaskURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
            
            let deleteJSONDataDeleteTask: URLSessionDataTask = self.session!.dataTask(with: deleteTaskURL, completionHandler: {
                (data, response, error) in
                
                guard error == nil else {
                    print("Error with connection")
                    return
                }
                
                let status = (response as! HTTPURLResponse).statusCode
                if status == 200 {
                    
                    DispatchQueue.main.async {
                        self.tasksArray.remove(at: indexPath.row)
                        tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
                        self.recountIncomplete()
                        self.cachable = false
                        self.callGetTasksAPI()
                    }
                }
                else if status == 401 {

                    if attempts > 0 {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Error", message: "Your session has timed out - please log in again - 1", preferredStyle: .alert)
                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                self.dismiss(animated: true, completion: nil)
                            })
                            
                            alert.addAction(alertAct)
                            self.present(alert, animated: true)
                        }
                    }
                    else {
                        attempts = 1
                        
                        var refreshSessionURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions/\(String(describing: self.sessionid))")!)
                        
                        refreshSessionURL.httpMethod = "PATCH"
                        refreshSessionURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                        refreshSessionURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                        
                        let json: [String: Any] = ["refresh_token": self.refreshToken]
                        let jsonData = try? JSONSerialization.data(withJSONObject: json)
                        
                        refreshSessionURL.httpBody = jsonData
                        
                        let downloadJSONDataTaskRefreshSession: URLSessionDataTask = self.session!.dataTask(with: refreshSessionURL, completionHandler: {
                            (data, response, error) in
                            
                            guard error == nil else {
                                print("Error with connection")
                                return
                            }
                            
                            let status = (response as! HTTPURLResponse).statusCode
                            
                            if status == 200 {
                                do {
                                    let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                                    let jsonData = json?["data"] as! [String:Any]
                                    let sessionid = jsonData["session_id"] as! Int
                                    let accesstoken = jsonData["access_token"] as! String
                                    let refreshtoken = jsonData["refresh_token"] as! String
                                    UserDefaults.standard.set(accesstoken, forKey: "accessToken")
                                    UserDefaults.standard.set(refreshtoken, forKey: "refreshToken")
                                    UserDefaults.standard.set(sessionid, forKey: "sessionID")
                                    
                                    DispatchQueue.main.async {
                                        
                                        if let savedAccessToken = UserDefaults.standard.string(forKey: "accessToken"), let savedRefreshToken = UserDefaults.standard.string(forKey: "refreshToken") , let savedSessionID = UserDefaults.standard.string(forKey: "sessionID") {
                                            self.accessToken = savedAccessToken
                                            self.refreshToken = savedRefreshToken
                                            self.sessionid = Int(savedSessionID)!
                                            
                                            deleteTaskURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                                            
                                            let deleteJSONDataDeleteTask: URLSessionDataTask = self.session!.dataTask(with: deleteTaskURL, completionHandler: {
                                                (data, response, error) in
                                                
                                                guard error == nil else {
                                                    print("Error with connection")
                                                    return
                                                }
                                                
                                                let status = (response as! HTTPURLResponse).statusCode
                                                if status == 200 {
                                                    
                                                    DispatchQueue.main.async {
                                                        self.tasksArray.remove(at: indexPath.row)
                                                        tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
                                                        self.recountIncomplete()
                                                        self.cachable = false
                                                        self.callGetTasksAPI()
                                                    }
                                                }
                                                else if status == 401 {
                                                    DispatchQueue.main.async {
                                                        let alert = UIAlertController(title: "Error", message: "There was an error logging in - please log in again. - 2", preferredStyle: .alert)
                                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                                            self.dismiss(animated: true, completion: nil)
                                                        })
                                                        
                                                        alert.addAction(alertAct)
                                                        self.present(alert, animated: true)
                                                    }
                                                }
                                                else {
                                                    DispatchQueue.main.async {
                                                        let alert = UIAlertController(title: "Error", message: "Cannot delete task - please try again", preferredStyle: .alert)
                                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                            
                                                        })
                                                        
                                                        alert.addAction(alertAct)
                                                        self.present(alert, animated: true)
                                                    }
                                                }
                                            })
                                            
                                            deleteJSONDataDeleteTask.resume()
                                            
                                            
                                        }
                                        else {
                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                            self.dismiss(animated: true, completion: nil)
                                        }
                                    }
                                }
                                catch {
                                    DispatchQueue.main.async {
                                        print("error in JSONSerialization")
                                        let alert = UIAlertController(title: "Error", message: "There was an error logging in. - 3", preferredStyle: .alert)
                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                            self.dismiss(animated: true, completion: nil)
                                        })
                                        
                                        alert.addAction(alertAct)
                                        self.present(alert, animated: true)
                                    }
                                }
                            }
                            else {
                                DispatchQueue.main.async {
                                    print("There was an error logging in");
                                    let alert = UIAlertController(title: "Error", message: "There was an error refreshing token - please log in again. - 4", preferredStyle: .alert)
                                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                        UserDefaults.standard.removeObject(forKey: "accessToken")
                                        UserDefaults.standard.removeObject(forKey: "refreshToken")
                                        UserDefaults.standard.removeObject(forKey: "sessionID")
                                        self.dismiss(animated: true, completion: nil)
                                    })
                                    
                                    alert.addAction(alertAct)
                                    self.present(alert, animated: true)
                                }
                            }
                            
                        })
                        
                        downloadJSONDataTaskRefreshSession.resume()
                    }
                }
                else {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Error", message: "Cannot delete task - please try again", preferredStyle: .alert)
                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                            
                        })
                        
                        alert.addAction(alertAct)
                        self.present(alert, animated: true)
                    }
                }

            })
            
            deleteJSONDataDeleteTask.resume()
        
        })
        
        if self.tasksArray[indexPath.row].getCompleted() == "N"
        {
            let completeAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Complete" , handler: { (action:UITableViewRowAction, indexPath:IndexPath) -> Void in
                
                var attempts: Int = 0
                let taskToPatch = self.tasksArray[indexPath.row]
                
                var setCompleteURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/tasks/\(String(describing: taskToPatch.getID()!))")!)
                
                setCompleteURL.httpMethod = "PATCH"
                setCompleteURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                setCompleteURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                
                let json: [String: Any] = ["completed": "Y"]
                let jsonData = try? JSONSerialization.data(withJSONObject: json)
                setCompleteURL.httpBody = jsonData
                
                let patchJSONDataSetTaskComplete: URLSessionDataTask = self.session!.dataTask(with: setCompleteURL, completionHandler: {
                    (data, response, error) in
    
                    guard error == nil else {
                        print("Error with connection")
                        return
                    }
                    
                    let status = (response as! HTTPURLResponse).statusCode
                    if status == 200 {
                        DispatchQueue.main.async {
                            self.tasksArray[indexPath.row].setCompleted(completed: "Y")
                            self.tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.none)
                            self.recountIncomplete()
                            self.cachable = false
                            self.callGetTasksAPI()
                        }
                    }
                    else if status == 401 {
                        
                        if attempts > 0 {
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Error", message: "Your session has timed out - please log in again - 5", preferredStyle: .alert)
                                let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                    UserDefaults.standard.removeObject(forKey: "accessToken")
                                    UserDefaults.standard.removeObject(forKey: "refreshToken")
                                    UserDefaults.standard.removeObject(forKey: "sessionID")
                                    self.dismiss(animated: true, completion: nil)
                                })
                                
                                alert.addAction(alertAct)
                                self.present(alert, animated: true)
                            }
                        }
                        else {
                            attempts = 1
                            
                            var refreshSessionURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions/\(String(describing: self.sessionid))")!)
                            
                            refreshSessionURL.httpMethod = "PATCH"
                            refreshSessionURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                            refreshSessionURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                            
                            let json: [String: Any] = ["refresh_token": self.refreshToken]
                            let jsonData = try? JSONSerialization.data(withJSONObject: json)
                            
                            refreshSessionURL.httpBody = jsonData
                            
                            let downloadJSONDataTaskRefreshSession: URLSessionDataTask = self.session!.dataTask(with: refreshSessionURL, completionHandler: {
                                (data, response, error) in
                                
                                guard error == nil else {
                                    print("Error with connection")
                                    return
                                }
                                
                                let status = (response as! HTTPURLResponse).statusCode
                                
                                if status == 200 {
                                    do {
                                        let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                                        let jsonData = json?["data"] as! [String:Any]
                                        let sessionid = jsonData["session_id"] as! Int
                                        let accesstoken = jsonData["access_token"] as! String
                                        let refreshtoken = jsonData["refresh_token"] as! String
                                        UserDefaults.standard.set(accesstoken, forKey: "accessToken")
                                        UserDefaults.standard.set(refreshtoken, forKey: "refreshToken")
                                        UserDefaults.standard.set(sessionid, forKey: "sessionID")
                                        
                                        DispatchQueue.main.async {
                                            
                                            if let savedAccessToken = UserDefaults.standard.string(forKey: "accessToken"), let savedRefreshToken = UserDefaults.standard.string(forKey: "refreshToken") , let savedSessionID = UserDefaults.standard.string(forKey: "sessionID") {
                                                self.accessToken = savedAccessToken
                                                self.refreshToken = savedRefreshToken
                                                self.sessionid = Int(savedSessionID)!
                                                
                                                setCompleteURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                                                
                                                let patchJSONDataSetTaskComplete: URLSessionDataTask = self.session!.dataTask(with: setCompleteURL, completionHandler: {
                                                    (data, response, error) in
                                                    
                                                    guard error == nil else {
                                                        print("Error with connection")
                                                        return
                                                    }
                                                    
                                                    let status = (response as! HTTPURLResponse).statusCode
                                                    if status == 200 {
                                                        DispatchQueue.main.async {
                                                            self.tasksArray[indexPath.row].setCompleted(completed: "Y")
                                                            self.tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.none)
                                                            self.recountIncomplete()
                                                            self.cachable = false
                                                            self.callGetTasksAPI()
                                                        }
                                                    }
                                                    else if status == 401 {
                                                        DispatchQueue.main.async {
                                                            let alert = UIAlertController(title: "Error", message: "There was an error logging in - please log in again. - 6", preferredStyle: .alert)
                                                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                                                self.dismiss(animated: true, completion: nil)
                                                            })
                                                            
                                                            alert.addAction(alertAct)
                                                            self.present(alert, animated: true)
                                                        }
                                                    }
                                                    else {
                                                        DispatchQueue.main.async {
                                                            let alert = UIAlertController(title: "Error", message: "Failed to set task as complete - please try again. - 7", preferredStyle: .alert)
                                                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                            })
                                                            
                                                            alert.addAction(alertAct)
                                                            self.present(alert, animated: true)
                                                        }
                                                    }
                                                    
                                                })
                                                
                                                patchJSONDataSetTaskComplete.resume()
                                            }
                                            else {
                                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                                self.dismiss(animated: true, completion: nil)
                                            }
                                        }
                                    }
                                    catch {
                                        DispatchQueue.main.async {
                                            print("error in JSONSerialization")
                                            let alert = UIAlertController(title: "Error", message: "There was an error logging in.", preferredStyle: .alert)
                                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                                self.dismiss(animated: true, completion: nil)
                                            })
                                            
                                            alert.addAction(alertAct)
                                            self.present(alert, animated: true)
                                        }
                                    }
                                }
                                else {
                                    DispatchQueue.main.async {
                                        print("There was an error logging in");
                                        let alert = UIAlertController(title: "Error", message: "There was an error refreshing token - please log in again. - 8", preferredStyle: .alert)
                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                            self.dismiss(animated: true, completion: nil)
                                        })
                                        
                                        alert.addAction(alertAct)
                                        self.present(alert, animated: true)
                                    }
                                }
                                
                            })
                            
                            downloadJSONDataTaskRefreshSession.resume()
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Error", message: "Failed to set task as complete - please try again.", preferredStyle: .alert)
                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                            })
                                
                            alert.addAction(alertAct)
                            self.present(alert, animated: true)
                        }
                    }
 
                })
                
                patchJSONDataSetTaskComplete.resume()

            })
            return [deleteAction, completeAction]
        }
        else
        {
            let uncompleteAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Uncomplete" , handler: { (action:UITableViewRowAction, indexPath:IndexPath) -> Void in
                
                var attempts: Int = 0
                let taskToPatch = self.tasksArray[indexPath.row]
                
                var setCompleteURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/tasks/\(String(describing: taskToPatch.getID()!))")!)
                
                setCompleteURL.httpMethod = "PATCH"
                setCompleteURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                setCompleteURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                
                let json: [String: Any] = ["completed": "N"]
                let jsonData = try? JSONSerialization.data(withJSONObject: json)
                setCompleteURL.httpBody = jsonData
                
                let patchJSONDataSetTaskComplete: URLSessionDataTask = self.session!.dataTask(with: setCompleteURL, completionHandler: {
                    (data, response, error) in
                    
                    guard error == nil else {
                        print("Error with connection")
                        return
                    }
                    
                    let status = (response as! HTTPURLResponse).statusCode
                    if status == 200 {
                        DispatchQueue.main.async {
                            self.tasksArray[indexPath.row].setCompleted(completed: "N")
                            self.tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.none)
                            self.recountIncomplete()
                            self.cachable = false
                            self.callGetTasksAPI()
                        }
                    }
                    else if status == 401 {
                        
                        if attempts > 0 {
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Error", message: "Your session has timed out - please log in again - 9", preferredStyle: .alert)
                                let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                    UserDefaults.standard.removeObject(forKey: "accessToken")
                                    UserDefaults.standard.removeObject(forKey: "refreshToken")
                                    UserDefaults.standard.removeObject(forKey: "sessionID")
                                    self.dismiss(animated: true, completion: nil)
                                })
                                
                                alert.addAction(alertAct)
                                self.present(alert, animated: true)
                            }
                        }
                        else {
                            attempts = 1
                            
                            var refreshSessionURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions/\(String(describing: self.sessionid))")!)
                            
                            refreshSessionURL.httpMethod = "PATCH"
                            refreshSessionURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                            refreshSessionURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                            
                            let json: [String: Any] = ["refresh_token": self.refreshToken]
                            let jsonData = try? JSONSerialization.data(withJSONObject: json)
                            
                            refreshSessionURL.httpBody = jsonData
                            
                            let downloadJSONDataTaskRefreshSession: URLSessionDataTask = self.session!.dataTask(with: refreshSessionURL, completionHandler: {
                                (data, response, error) in
                                
                                guard error == nil else {
                                    print("Error with connection")
                                    return
                                }
                                
                                let status = (response as! HTTPURLResponse).statusCode
                                
                                if status == 200 {
                                    do {
                                        let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                                        let jsonData = json?["data"] as! [String:Any]
                                        let sessionid = jsonData["session_id"] as! Int
                                        let accesstoken = jsonData["access_token"] as! String
                                        let refreshtoken = jsonData["refresh_token"] as! String
                                        UserDefaults.standard.set(accesstoken, forKey: "accessToken")
                                        UserDefaults.standard.set(refreshtoken, forKey: "refreshToken")
                                        UserDefaults.standard.set(sessionid, forKey: "sessionID")
                                        
                                        DispatchQueue.main.async {
                                            
                                            if let savedAccessToken = UserDefaults.standard.string(forKey: "accessToken"), let savedRefreshToken = UserDefaults.standard.string(forKey: "refreshToken") , let savedSessionID = UserDefaults.standard.string(forKey: "sessionID") {
                                                self.accessToken = savedAccessToken
                                                self.refreshToken = savedRefreshToken
                                                self.sessionid = Int(savedSessionID)!
                                                
                                                setCompleteURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                                                
                                                let patchJSONDataSetTaskComplete: URLSessionDataTask = self.session!.dataTask(with: setCompleteURL, completionHandler: {
                                                    (data, response, error) in
                                                    
                                                    guard error == nil else {
                                                        print("Error with connection")
                                                        return
                                                    }
                                                    
                                                    let status = (response as! HTTPURLResponse).statusCode
                                                    if status == 200 {
                                                        DispatchQueue.main.async {
                                                            self.tasksArray[indexPath.row].setCompleted(completed: "Y")
                                                            self.tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.none)
                                                            self.recountIncomplete()
                                                            self.cachable = false
                                                            self.callGetTasksAPI()
                                                        }
                                                    }
                                                    else if status == 401 {
                                                        DispatchQueue.main.async {
                                                            let alert = UIAlertController(title: "Error", message: "There was an error logging in - please log in again. - 10", preferredStyle: .alert)
                                                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                                                self.dismiss(animated: true, completion: nil)
                                                            })
                                                            
                                                            alert.addAction(alertAct)
                                                            self.present(alert, animated: true)
                                                        }
                                                    }
                                                    else {
                                                        DispatchQueue.main.async {
                                                            let alert = UIAlertController(title: "Error", message: "Failed to set task as incomplete - please try again. - 11", preferredStyle: .alert)
                                                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                            })
                                                            
                                                            alert.addAction(alertAct)
                                                            self.present(alert, animated: true)
                                                        }
                                                    }
                                                    
                                                })
                                                
                                                patchJSONDataSetTaskComplete.resume()
                                            }
                                            else {
                                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                                self.dismiss(animated: true, completion: nil)
                                            }
                                        }
                                    }
                                    catch {
                                        DispatchQueue.main.async {
                                            print("error in JSONSerialization")
                                            let alert = UIAlertController(title: "Error", message: "There was an error logging in. - 12", preferredStyle: .alert)
                                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                                self.dismiss(animated: true, completion: nil)
                                            })
                                            
                                            alert.addAction(alertAct)
                                            self.present(alert, animated: true)
                                        }
                                    }
                                }
                                else {
                                    DispatchQueue.main.async {
                                        print("There was an error logging in");
                                        let alert = UIAlertController(title: "Error", message: "There was an error refreshing token - please log in again. - 13", preferredStyle: .alert)
                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                            self.dismiss(animated: true, completion: nil)
                                        })
                                        
                                        alert.addAction(alertAct)
                                        self.present(alert, animated: true)
                                    }
                                }
                                
                            })
                            
                            downloadJSONDataTaskRefreshSession.resume()
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Error", message: "Failed to set task as incomplete - please try again.", preferredStyle: .alert)
                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                            })
                            
                            alert.addAction(alertAct)
                            self.present(alert, animated: true)
                        }
                    }
                    
                })
                
                patchJSONDataSetTaskComplete.resume()
                
            })
            return [deleteAction, uncompleteAction]
        }
    }

    @IBAction func refreshTasks(_ sender: Any) {
        self.tasksArray.removeAll()
        self.tableView.reloadData()
        callGetTasksAPI()
    }
    
    
    private func recountIncomplete()
    {
        self.numberIncomplete = 0
        for task in tasksArray {
            if task.getCompleted() == "N" {
                self.numberIncomplete = self.numberIncomplete+1
            }
        }
        self.title = "Tasks - \(self.numberIncomplete)"
    }
    
    
    
    @IBAction func logoutButtonPressed(_ sender: Any) {
        
        var logoutSessionURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions/\(String(describing: self.sessionid))")!)
        
        logoutSessionURL.httpMethod = "DELETE"
        logoutSessionURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
        let deleteLogOutSession: URLSessionDataTask = self.session!.dataTask(with: logoutSessionURL, completionHandler: {
            (data, response, error) in
            
            guard error == nil else {
                print("Error with connection")
                return
            }
                
            DispatchQueue.main.async {
                UserDefaults.standard.removeObject(forKey: "accessToken")
                UserDefaults.standard.removeObject(forKey: "refreshToken")
                UserDefaults.standard.removeObject(forKey: "sessionID")
                self.dismiss(animated: false, completion: nil)
            }
  
        })
        
        deleteLogOutSession.resume()
    }
    

    
    @IBAction func addButtonPressed(_ sender: Any) {
        var attempts: Int = 0
        let alertController = UIAlertController(title: "Add New Task", message: "", preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
            let title = alertController.textFields![0] as UITextField
            let description = alertController.textFields![1] as UITextField
            let deadline = alertController.textFields![2] as UITextField
            let completed = alertController.textFields![3] as UITextField
            
            var addTaskUrl: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/tasks")!)
            
            addTaskUrl.httpMethod = "POST"
            addTaskUrl.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
            addTaskUrl.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            var json: [String: Any] = ["title": "\(title.text!)","description": "\(description.text!)","deadline": "\(deadline.text!)","completed": "\(completed.text!)"]
            if(deadline.text == "") {
                json.removeValue(forKey: "deadline")
            }
            if(description.text == "") {
                json.removeValue(forKey: "description")
            }
            let jsonData = try? JSONSerialization.data(withJSONObject: json)
            addTaskUrl.httpBody = jsonData
            
            let postJSONDataAddTask: URLSessionDataTask = self.session!.dataTask(with: addTaskUrl, completionHandler: {
                (data, response, error) in
                
                guard error == nil else {
                    print("Error with connection")
                    return
                }
                
                let status = (response as! HTTPURLResponse).statusCode

                if status == 201 {
                    
                    DispatchQueue.main.async {
                        self.cachable = false
                        self.callGetTasksAPI()
                    }
                }
                else if status == 401 {
                    
                    if attempts > 0 {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Error", message: "Your session has timed out - please log in again - 14", preferredStyle: .alert)
                            let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                UserDefaults.standard.removeObject(forKey: "accessToken")
                                UserDefaults.standard.removeObject(forKey: "refreshToken")
                                UserDefaults.standard.removeObject(forKey: "sessionID")
                                self.dismiss(animated: true, completion: nil)
                            })
                            
                            alert.addAction(alertAct)
                            self.present(alert, animated: true)
                        }
                    }
                    else {
                        attempts = 1
                        
                        var refreshSessionURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions/\(String(describing: self.sessionid))")!)
                        
                        refreshSessionURL.httpMethod = "PATCH"
                        refreshSessionURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                        refreshSessionURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                        
                        let json: [String: Any] = ["refresh_token": self.refreshToken]
                        let jsonData = try? JSONSerialization.data(withJSONObject: json)
                        
                        refreshSessionURL.httpBody = jsonData
                        
                        let downloadJSONDataTaskRefreshSession: URLSessionDataTask = self.session!.dataTask(with: refreshSessionURL, completionHandler: {
                            (data, response, error) in
                            
                            guard error == nil else {
                                print("Error with connection")
                                return
                            }
                            
                            let status = (response as! HTTPURLResponse).statusCode
                            
                            if status == 200 {
                                do {
                                    let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                                    let jsonData = json?["data"] as! [String:Any]
                                    let sessionid = jsonData["session_id"] as! Int
                                    let accesstoken = jsonData["access_token"] as! String
                                    let refreshtoken = jsonData["refresh_token"] as! String
                                    UserDefaults.standard.set(accesstoken, forKey: "accessToken")
                                    UserDefaults.standard.set(refreshtoken, forKey: "refreshToken")
                                    UserDefaults.standard.set(sessionid, forKey: "sessionID")
                                    
                                    DispatchQueue.main.async {
                                        
                                        if let savedAccessToken = UserDefaults.standard.string(forKey: "accessToken"), let savedRefreshToken = UserDefaults.standard.string(forKey: "refreshToken") , let savedSessionID = UserDefaults.standard.string(forKey: "sessionID") {
                                            self.accessToken = savedAccessToken
                                            self.refreshToken = savedRefreshToken
                                            self.sessionid = Int(savedSessionID)!
                                            
                                            addTaskUrl.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                                            
                                            let postJSONDataAddTask: URLSessionDataTask =  self.session!.dataTask(with: addTaskUrl, completionHandler: {
                                                (data, response, error) in
                                                
                                                guard error == nil else {
                                                    print("Error with connection")
                                                    return
                                                }
                                                
                                                let status = (response as! HTTPURLResponse).statusCode
                                                
                                                if status == 201 {
                                                    
                                                    DispatchQueue.main.async {
                                                        self.cachable = false
                                                        self.callGetTasksAPI()
                                                    }
                                                }
                                                else if status == 401 {
                                                    DispatchQueue.main.async {
                                                        print("error in JSONSerialization")
                                                        let alert = UIAlertController(title: "Error", message: "There was an error logging in. - 15", preferredStyle: .alert)
                                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                                            self.dismiss(animated: true, completion: nil)
                                                        })
                                                        
                                                        alert.addAction(alertAct)
                                                        self.present(alert, animated: true)
                                                    }
                                                }
                                                else {
                                                    DispatchQueue.main.async {
                                                        let alert = UIAlertController(title: "Error", message: "There was an error adding new task.", preferredStyle: .alert)
                                                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                                                        self.present(alert, animated: true)
                                                    }
                                                }
                                            })
                                            
                                            postJSONDataAddTask.resume()
                                        }
                                        else {
                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                            self.dismiss(animated: true, completion: nil)
                                        }
                                    }
                                }
                                catch {
                                    DispatchQueue.main.async {
                                        print("error in JSONSerialization")
                                        let alert = UIAlertController(title: "Error", message: "There was an error logging in.", preferredStyle: .alert)
                                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                            UserDefaults.standard.removeObject(forKey: "accessToken")
                                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                                            UserDefaults.standard.removeObject(forKey: "sessionID")
                                            self.dismiss(animated: true, completion: nil)
                                        })
                                        
                                        alert.addAction(alertAct)
                                        self.present(alert, animated: true)
                                    }
                                }
                            }
                            else {
                                DispatchQueue.main.async {
                                    print("There was an error logging in");
                                    let alert = UIAlertController(title: "Error", message: "There was an error refreshing token - please log in again. - 16", preferredStyle: .alert)
                                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                        UserDefaults.standard.removeObject(forKey: "accessToken")
                                        UserDefaults.standard.removeObject(forKey: "refreshToken")
                                        UserDefaults.standard.removeObject(forKey: "sessionID")
                                        self.dismiss(animated: true, completion: nil)
                                    })
                                    
                                    alert.addAction(alertAct)
                                    self.present(alert, animated: true)
                                }
                            }
                            
                        })
                        
                        downloadJSONDataTaskRefreshSession.resume()
                    }
                }
                else {
                    
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Error", message: "There was an error adding new task.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                        self.present(alert, animated: true)
                    }
                }
            })
            
            postJSONDataAddTask.resume()
            
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: { (action : UIAlertAction!) -> Void in })
        
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter title"
        }
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter description"
        }
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter deadline (dd/mm/yyyy hh:mm)"
        }
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Completed? (Y or N)"
        }
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    
    
    @objc func callGetTasksAPI() {
        self.refreshButton.isEnabled = false
        self.tasksArray.removeAll()
        self.tableView.reloadData()
        var attempts: Int = 0
        
        var url: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/tasks")!)
        
        url.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
        
        if(!self.cachable) {
            url.cachePolicy = .reloadIgnoringLocalCacheData
        }
        
        let getTasksAPIDataTask: URLSessionDataTask = self.session!.dataTask(with: url, completionHandler: {
            (data, response, error) in
            
            // check if there has been an error
            guard error == nil else {
                print("Error with connection")
                self.refreshButton.isEnabled = true
                return
            }
            
            let status = (response as! HTTPURLResponse).statusCode
            print(status)
            if status == 200 {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                    let jsonData = json?["data"] as! [String:Any]
                    let tasks = jsonData["tasks"] as! [[String:Any]]
                    
                    for task in tasks {
                        let tempTask = Task(id: task["id"] as! UInt, title: task["title"] as! String, description: task["description"] as? String, deadline: task["deadline"] as? String, completed: task["completed"] as! String)
                        
                        self.tasksArray.append(tempTask)
                    }
                    
                    DispatchQueue.main.async {
                        self.recountIncomplete()
                        self.tableView.reloadData()
                        self.cachable = true
                        self.refreshButton.isEnabled = true
                    }
                    
                }
                catch {
                    print("error in JSONSerialization")
                    self.refreshButton.isEnabled = true
                }
            }
            else if status == 401 {
                if attempts > 0 {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Error", message: "Your session has timed out - please log in again - 17", preferredStyle: .alert)
                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                            UserDefaults.standard.removeObject(forKey: "accessToken")
                            UserDefaults.standard.removeObject(forKey: "refreshToken")
                            UserDefaults.standard.removeObject(forKey: "sessionID")
                            self.dismiss(animated: true, completion: nil)
                        })
                            
                        alert.addAction(alertAct)
                        self.present(alert, animated: true)
                    }
                }
                else {
                    attempts = 1
                    
                    var refreshSessionURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions/\(String(describing: self.sessionid))")!)
                    
                    refreshSessionURL.httpMethod = "PATCH"
                    refreshSessionURL.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                    refreshSessionURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
                    
                    let json: [String: Any] = ["refresh_token": self.refreshToken]
                    let jsonData = try? JSONSerialization.data(withJSONObject: json)
                    
                    refreshSessionURL.httpBody = jsonData
                    
                    let downloadJSONDataTaskRefreshSession: URLSessionDataTask = self.session!.dataTask(with: refreshSessionURL, completionHandler: {
                        (data, response, error) in
                        
                        guard error == nil else {
                            print("Error with connection")
                            return
                        }
                        
                        let status = (response as! HTTPURLResponse).statusCode
                        
                        if status == 200 {
                            do {
                                let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                                let jsonData = json?["data"] as! [String:Any]
                                let sessionid = jsonData["session_id"] as! Int
                                let accesstoken = jsonData["access_token"] as! String
                                let refreshtoken = jsonData["refresh_token"] as! String
                                UserDefaults.standard.set(accesstoken, forKey: "accessToken")
                                UserDefaults.standard.set(refreshtoken, forKey: "refreshToken")
                                UserDefaults.standard.set(sessionid, forKey: "sessionID")
                                
                                DispatchQueue.main.async {
                                    
                                    if let savedAccessToken = UserDefaults.standard.string(forKey: "accessToken"), let savedRefreshToken = UserDefaults.standard.string(forKey: "refreshToken") , let savedSessionID = UserDefaults.standard.string(forKey: "sessionID") {
                                        self.accessToken = savedAccessToken
                                        self.refreshToken = savedRefreshToken
                                        self.sessionid = Int(savedSessionID)!
                                        
                                        url.setValue("\(self.accessToken)", forHTTPHeaderField: "Authorization")
                                        
                                        let getTasksAPIDataTask: URLSessionDataTask = self.session!.dataTask(with: url, completionHandler: {
                                            (data, response, error) in
                                            
                                            // check if there has been an error
                                            guard error == nil else {
                                                print("Error with connection")
                                                self.refreshButton.isEnabled = true
                                                return
                                            }
                                            
                                            let status = (response as! HTTPURLResponse).statusCode
                                            
                                            if status == 200 {
                                                
                                                do {
                                                    let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                                                    let jsonData = json?["data"] as! [String:Any]
                                                    let tasks = jsonData["tasks"] as! [[String:Any]]
                                                    
                                                    for task in tasks {
                                                        let tempTask = Task(id: task["id"] as! UInt, title: task["title"] as! String, description: task["description"] as? String, deadline: task["deadline"] as? String, completed: task["completed"] as! String)
                                                        
                                                        self.tasksArray.append(tempTask)
                                                    }
                                                    
                                                    DispatchQueue.main.async {
                                                        self.recountIncomplete()
                                                        self.tableView.reloadData()
                                                        self.cachable = true
                                                        self.refreshButton.isEnabled = true
                                                    }
                                                    
                                                }
                                                catch {
                                                    print("error in JSONSerialization")
                                                    self.refreshButton.isEnabled = true
                                                }
                                            }
                                            else {
                                                DispatchQueue.main.async {
                                                    let alert = UIAlertController(title: "Error", message: "There was an error logging in. - 18", preferredStyle: .alert)
                                                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                                        UserDefaults.standard.removeObject(forKey: "accessToken")
                                                        UserDefaults.standard.removeObject(forKey: "refreshToken")
                                                        UserDefaults.standard.removeObject(forKey: "sessionID")
                                                        self.dismiss(animated: true, completion: nil)
                                                    })
                                                    
                                                    alert.addAction(alertAct)
                                                    self.present(alert, animated: true)
                                                }
                                            }
                                        })
                                        getTasksAPIDataTask.resume()
 
                                    }
                                    else {
                                        UserDefaults.standard.removeObject(forKey: "accessToken")
                                        UserDefaults.standard.removeObject(forKey: "refreshToken")
                                        UserDefaults.standard.removeObject(forKey: "sessionID")
                                        self.dismiss(animated: true, completion: nil)
                                    }
                                }
                            }
                            catch {
                                DispatchQueue.main.async {
                                    print("error in JSONSerialization")
                                    let alert = UIAlertController(title: "Error", message: "There was an error logging in. - 19", preferredStyle: .alert)
                                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                        UserDefaults.standard.removeObject(forKey: "accessToken")
                                        UserDefaults.standard.removeObject(forKey: "refreshToken")
                                        UserDefaults.standard.removeObject(forKey: "sessionID")
                                        self.dismiss(animated: true, completion: nil)
                                    })
                                        
                                    alert.addAction(alertAct)
                                    self.present(alert, animated: true)
                                }
                            }
                        }
                        else {
                            DispatchQueue.main.async {
                                print("There was an error logging in");
                                let alert = UIAlertController(title: "Error", message: "There was an error refreshing token - please log in again. - 20 - \(status)", preferredStyle: .alert)
                                let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                    UserDefaults.standard.removeObject(forKey: "accessToken")
                                    UserDefaults.standard.removeObject(forKey: "refreshToken")
                                    UserDefaults.standard.removeObject(forKey: "sessionID")
                                    self.dismiss(animated: true, completion: nil)
                                })
                                    
                                alert.addAction(alertAct)
                                self.present(alert, animated: true)
                            }
                        }

                    })
                        
                    downloadJSONDataTaskRefreshSession.resume()
                }
            }
            else {
                DispatchQueue.main.async {
                    
                    let alert = UIAlertController(title: "Error", message: "An error has occured - please log in again - 21", preferredStyle: .alert)
                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                        UserDefaults.standard.removeObject(forKey: "accessToken")
                        UserDefaults.standard.removeObject(forKey: "refreshToken")
                        UserDefaults.standard.removeObject(forKey: "sessionID")
                        self.dismiss(animated: true, completion: nil)
                    })
                    
                    alert.addAction(alertAct)
                    self.present(alert, animated: true)
                }
            }

        })
        
        getTasksAPIDataTask.resume()
    }

}
