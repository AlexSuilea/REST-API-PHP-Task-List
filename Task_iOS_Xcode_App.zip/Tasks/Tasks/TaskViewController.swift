//
//  TaskViewController.swift
//  ToDoDemo
//
//  Created by Michael Spinks on 04/12/2018.
//  Copyright © 2018 Michael Spinks. All rights reserved.
//

import UIKit

class TaskViewController: UIViewController {
    
    public var passedInTask: Task?

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var deadlineLabel: UILabel!
    @IBOutlet weak var completedLabel: UILabel!
    
    override func viewDidLoad() {
        
        if(passedInTask != nil)
        {
            self.title = "ID: \(passedInTask!.getID()!)"
            titleLabel.text = passedInTask?.getTitle()
            descriptionLabel.text = passedInTask?.getDescription()
            if passedInTask?.getDeadline() != nil
            {
                deadlineLabel.text = passedInTask?.getDeadline()
            }
            else
            {
                deadlineLabel.text = "None"
            }
            completedLabel.text = passedInTask?.getCompleted()
        }
    }
    
}
