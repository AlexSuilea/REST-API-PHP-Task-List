//
//  Task.swift
//  ToDoDemo
//
//  Created by Michael Spinks on 04/12/2018.
//  Copyright © 2018 Michael Spinks. All rights reserved.
//

import Foundation

class Task {
    private var _id: UInt?
    private var _title: String
    private var _description: String?
    private var _deadline: String?
    private var _completed: String
    
    init(id: UInt, title: String, description: String?, deadline: String?, completed: String) {
        self._id = id
        self._title = title
        self._description = description
        self._deadline = deadline
        self._completed = completed
    }
    
    public func getID() -> UInt? {
        return self._id
    }
    
    public func getTitle() -> String {
        return self._title
    }
    
    public func getDescription() -> String? {
        return self._description
    }
    
    public func getDeadline() -> String? {
        return self._deadline
    }
    
    public func getCompleted() -> String {
        return self._completed
    }
    
    public func setTitle(title: String) {
        self._title = title
    }
    
    public func setDescription(description: String) {
        self._description = description
    }
    
    public func setDeadline(deadline: String) {
        self._deadline = deadline
    }
    
    public func setCompleted(completed: String) {
        self._completed = completed
    }
    
}
