//
//  SignUpViewController.swift
//  Tasks
//
//  Created by Michael Spinks on 23/12/2018.
//  Copyright © 2018 Michael Spinks. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    @IBOutlet weak var fullnameTextBox: UITextField!
    @IBOutlet weak var usernameTextBox: UITextField!
    @IBOutlet weak var passwordTextBox: UITextField!
    @IBOutlet weak var signupButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    
    private var apiURL: String = ""
    private let config = URLSessionConfiguration.default
    private var session: URLSession?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.apiURL = Bundle.main.object(forInfoDictionaryKey: "APIUrl") as! String
        self.config.timeoutIntervalForRequest = 30
        self.session = URLSession(configuration: self.config)
    }
    
    
    @IBAction func signupButtonPressed(_ sender: Any) {
        
        self.fullnameTextBox.resignFirstResponder()
        self.usernameTextBox.resignFirstResponder()
        self.passwordTextBox.resignFirstResponder()
        
        self.signupButton.setTitle("Signing up....", for: .normal)
        self.signupButton.isEnabled = false
        
        if self.fullnameTextBox.text == "" || self.usernameTextBox.text == "" || self.passwordTextBox.text == ""  {
            self.signupButton.setTitle("Sign up", for: .normal)
            self.signupButton.isEnabled = true
            let alert = UIAlertController(title: "Error", message: "You must provide a full name, username and password to sign up...", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        
        var signUpUserURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/users")!)
        
        signUpUserURL.httpMethod = "POST"
        signUpUserURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let json: [String: Any] = ["fullname": "\(self.fullnameTextBox.text!)", "username": "\(self.usernameTextBox.text!)","password": "\(self.passwordTextBox.text!)"]
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        signUpUserURL.httpBody = jsonData
        
        
        let postSignUpUserDataTask: URLSessionDataTask = self.session!.dataTask(with: signUpUserURL, completionHandler: {
            (data, response, error) in

            guard error == nil else {
                print("Error with connection")
                self.signupButton.titleLabel?.text = "Sign up"
                self.signupButton.isEnabled = true
                return
            }
            
            let status = (response as! HTTPURLResponse).statusCode
            
            if status == 201 {
                do {
                    _ = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]

                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Success", message: "Your account has been created successfully", preferredStyle: .alert)
                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                            self.fullnameTextBox.text = ""
                            self.usernameTextBox.text = ""
                            self.passwordTextBox.text = ""
                            self.signupButton.setTitle("Sign up", for: .normal)
                            self.signupButton.isEnabled = true
                            self.dismiss(animated: true, completion: nil)
                        })
                            
                        alert.addAction(alertAct)
                        self.present(alert, animated: true)
                    }
                }
                catch {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Error", message: "An error occured whilst creating user account - please try again.", preferredStyle: .alert)
                        let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                            self.signupButton.setTitle("Sign up", for: .normal)
                            self.signupButton.isEnabled = true
                        })
                            
                        alert.addAction(alertAct)
                        self.present(alert, animated: true)
                    }
                }
            }
            else if status == 409 {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Error", message: "Username already exits, please choose another one.", preferredStyle: .alert)
                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                        self.signupButton.setTitle("Sign up", for: .normal)
                        self.signupButton.isEnabled = true
                    })
                    
                    alert.addAction(alertAct)
                    self.present(alert, animated: true)
                }
            }
            else {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Error", message: "An error occured whilst creating user account - please try again.", preferredStyle: .alert)
                    let alertAct = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                        self.signupButton.setTitle("Sign up", for: .normal)
                        self.signupButton.isEnabled = true
                    })
                        
                    alert.addAction(alertAct)
                    self.present(alert, animated: true)
                }
            }
        })
        
        postSignUpUserDataTask.resume()
    }
    
    @IBAction func cancelButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
