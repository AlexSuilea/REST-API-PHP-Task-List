//
//  LoginViewController.swift
//  Tasks
//
//  Created by Michael Spinks on 17/12/2018.
//  Copyright © 2018 Michael Spinks. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameTextBox: UITextField!
    @IBOutlet weak var passwordTextBox: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    private var apiURL: String = ""
    private let config = URLSessionConfiguration.default
    private var session: URLSession?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        self.config.timeoutIntervalForRequest = 30
        self.session = URLSession(configuration: self.config)
        self.apiURL = Bundle.main.object(forInfoDictionaryKey: "APIUrl") as! String
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let _ = UserDefaults.standard.string(forKey: "accessToken"), let _ = UserDefaults.standard.string(forKey: "refreshToken") , let _ = UserDefaults.standard.string(forKey: "sessionID") {

            let nvc = self.storyboard?.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
            _ = nvc.viewControllers.first as! TaskTableViewController
            self.present(nvc, animated: false, completion: nil)
        }
    }
    
    @IBAction func loginButtonPressed(_ sender: Any) {
        self.usernameTextBox.resignFirstResponder()
        self.passwordTextBox.resignFirstResponder()
        self.session?.configuration.urlCache?.removeAllCachedResponses()
        
        self.loginButton.setTitle("Logging in....", for: .normal)
        self.loginButton.isEnabled = false
        
        if self.usernameTextBox.text == "" || self.passwordTextBox.text == ""  {
            self.loginButton.setTitle("Log in", for: .normal)
            self.loginButton.isEnabled = true
            let alert = UIAlertController(title: "Error", message: "You must provide a username and password to log in...", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        
        var postLogInURL: URLRequest = URLRequest(url: URL(string: "\(self.apiURL)/sessions")!)
        
        postLogInURL.httpMethod = "POST"
        postLogInURL.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let json: [String: Any] = ["username": "\(self.usernameTextBox.text!)","password": "\(self.passwordTextBox.text!)"]
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        postLogInURL.httpBody = jsonData
        
        
        let postLoginDataTask: URLSessionDataTask = self.session!.dataTask(with: postLogInURL, completionHandler: {
            (data, response, error) in
            
            guard error == nil else {
                print("Error with connection")
                self.loginButton.titleLabel?.text = "Log in"
                self.loginButton.isEnabled = true
                return
            }
            
            let status = (response as! HTTPURLResponse).statusCode
            if status == 201 {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                    let jsonData = json?["data"] as! [String:Any]
                    let sessionid = jsonData["session_id"] as! Int
                    let accesstoken = jsonData["access_token"] as! String
                    let refreshtoken = jsonData["refresh_token"] as! String
                    
                    DispatchQueue.main.async {
                        let nvc = self.storyboard?.instantiateViewController(withIdentifier: "navVC") as! UINavigationController
                        _ = nvc.viewControllers.first as! TaskTableViewController
                        UserDefaults.standard.set(accesstoken, forKey: "accessToken")
                        UserDefaults.standard.set(refreshtoken, forKey: "refreshToken")
                        UserDefaults.standard.set(sessionid, forKey: "sessionID")
                        self.present(nvc, animated: false, completion: nil)
                        self.usernameTextBox.text = ""
                        self.passwordTextBox.text = ""
                        self.loginButton.setTitle("Log in", for: .normal)
                        self.loginButton.isEnabled = true
    
                    }
                }
                catch {
                    DispatchQueue.main.async {
                        self.loginButton.setTitle("Log in", for: .normal)
                        self.loginButton.isEnabled = true
                        print("error in JSONSerialization")
                        let alert = UIAlertController(title: "Error", message: "There was an error logging in.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                        self.present(alert, animated: true)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    self.loginButton.setTitle("Log in", for: .normal)
                    self.loginButton.isEnabled = true
                    let alert = UIAlertController(title: "Error", message: "Username or password is incorrect.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(alert, animated: true)
                }
            }

        })
        
        postLoginDataTask.resume()
        
    }

}
