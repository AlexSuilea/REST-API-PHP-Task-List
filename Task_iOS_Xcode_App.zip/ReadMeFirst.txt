Due to popular demand this file contains the Xcode project for the demo iOS client app.

There is no support for this app as it was rushed together with no structured logic or architecture, technically it is not even finished, it was created literally just for demo purposes only.

Actions needed:

Open the Xcode project and open the info.plist file.

There is a parameter called APIUrl that you need to update to your URL end point.

Once updated build and run the app.